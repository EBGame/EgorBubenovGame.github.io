﻿{
	"version": 1556467883,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/minecircle-sheet0.png",
		"images/minecircle-sheet1.png",
		"images/effectwindow-sheet0.png",
		"images/loginvk-sheet0.png",
		"images/sprite-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"c2mp-net.js",
		"c2mp-peer.js",
		"c2mp.js",
		"waker.js",
		"xd_connection.js"
	]
}